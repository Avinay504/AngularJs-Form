

var app = angular.module('myApp', ['ngRoute']);


app.controller('HomeController', function($scope) {
	  $scope.message = 'Hello from HomeController';
	});

app.controller('CategoryController', function($scope) {
	  $scope.message = 'Hello from CategoryController';
	});

app.controller('ProductController', function($scope) {
	  $scope.message = 'Hello from ProductController';
	});

app.controller('SupplierController', function($scope) {
	  $scope.message = 'Hello from SupplierController';
	});




app.config(function($routeProvider) {
  $routeProvider

  .when('/', {
    templateUrl : 'ShoppingCart.html',
    controller  : 'HomeController'
  })

  .when('/categories', {
    templateUrl : 'view/categories.html',
    controller  : 'CategoryController'
  })

  .when('/products', {
    templateUrl : 'view/products.html',
    controller  : 'ProductController'
  })
  
   .when('/suppliers', {
    templateUrl : 'view/suppliers.html',
    controller  : 'SupplierController'
  })

  .otherwise({redirectTo: '/'});
});



