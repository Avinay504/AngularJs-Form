var app = angular.module('myApp', []);
app.controller('jobController', function($scope) {
	var self = this;
	self.job={id:"", title:""}
	
	self.getJobDetail = function getJobDetails()
	{  // function definition
		console.log("getJobDetails@@@@@@@@@@@@@") //logging
	    self.job={id:"JD001", title:"Technical Lead"}
		console.log(self.job)
	}
    self.getJobDetail()  // calling the function
	
	
	
	   
});