app.controller('userCtrl', function($scope) {
    $scope.firstName = "Abbas";
    $scope.lastName = "MD";
   
});