var app = angular.module('myApp', []);
//2
app.controller('jobController', function($scope) {
	
	$scope.job={id:"JD001", title:"Technical Lead"}
	   
});

